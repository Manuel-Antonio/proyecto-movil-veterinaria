package pe.proyecto.veterinariacomposable.ui

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import pe.proyecto.veterinariacomposable.ui.signup.ChangePassword
import pe.proyecto.veterinariacomposable.ui.signup.Login
import pe.proyecto.veterinariacomposable.ui.signup.Register
import pe.proyecto.veterinariacomposable.ui.cita.Cita
import pe.proyecto.veterinariacomposable.ui.cita.Dashboard
import pe.proyecto.veterinariacomposable.ui.pet.Pets

@ExperimentalMaterial3Api
@Composable 
fun Home() {
    val navController = rememberNavController()
    
    NavHost(navController = navController, startDestination = Route.Dashboard.route){
        composable(Route.Login.route) {
            Login(navController)
        }
        composable(Route.Register.route) {
            Register(navController)
        }
        composable(Route.ChangePassword.route) {
            ChangePassword(navController)
        }
        composable(Route.Cita.route) {
            Cita(navController)
        }
        composable(Route.Dashboard.route) {
            Dashboard(navController)
        }
        composable(Route.Pets.route) {
            Pets(navController)
        }

    }

}


sealed class Route(val route :String) {
    object Login : Route("login")
    object Register: Route("register")
    object ChangePassword: Route("changePassword")

    object Cita: Route("cita")
    object Dashboard: Route("dashboard")
    object Pets: Route("pets")


}