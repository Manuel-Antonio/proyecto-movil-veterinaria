package pe.proyecto.veterinariacomposable.data.model

import java.util.UUID

data class User(
    val id: Int,
    val code: UUID,
    val username: String,
    val email: String,
    val phone: String,
    val password: String
)
