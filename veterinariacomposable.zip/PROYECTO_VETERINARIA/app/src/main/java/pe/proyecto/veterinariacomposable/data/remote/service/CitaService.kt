package pe.proyecto.veterinariacomposable.data.remote.service

import retrofit2.Call
import retrofit2.http.POST
import retrofit2.http.Body
import pe.proyecto.veterinariacomposable.data.model.Cita
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path

interface CitaService {
    @PUT("citas/{id}")
    fun updateCita(@Path("id") id: Int, @Body cita: Cita): Call<Cita>

    @POST("citas")
    fun createCita(@Body cita: Cita): Call<Cita>

    @GET("citas")
    fun getCitas(): Call<List<Cita>>

    @DELETE("citas/{id}")
    fun deleteCita(@Path("id") id: Int): Call<Void>
}