package pe.proyecto.veterinariacomposable.ui.cita

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon

import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import pe.proyecto.veterinariacomposable.data.model.Cita
import pe.proyecto.veterinariacomposable.data.remote.ApiClient
import pe.proyecto.veterinariacomposable.ui.theme.VeterinariacomposableTheme
import retrofit2.Call
import retrofit2.Response
import java.util.UUID


@ExperimentalMaterial3Api
@Composable
fun Cita(navController: NavController) {
    var personName = remember {
        mutableStateOf("")
    }
    var personEmail = remember {
        mutableStateOf("")
    }
    var personPhone = remember {
        mutableStateOf("")
    }
    var petName = remember {
        mutableStateOf("")
    }
    var petCategory = remember {
        mutableStateOf("")
    }
    var petSymptoms = remember {
        mutableStateOf("")
    }



    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally


    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Seguimiento de Pacientes".toUpperCase(),
            textAlign = TextAlign.Center,
            fontWeight = FontWeight(900),
            fontSize = 42.sp,
            lineHeight = 48.sp,
            color = Color(0xFF0079FF),

        )

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Administra y añade pacientes",
            textAlign = TextAlign.Center,
            fontWeight = FontWeight(900),
            fontSize = 18.sp,
            lineHeight = 56.sp,
            color = Color(0xFF282A3A),
            letterSpacing = 2.sp
            )
        Spacer(modifier = Modifier.height(20.dp))
        //Campos

        //Campo: Propietario
        OutlinedTextField(
            label={ Text(text = "Nombre del Propietario")},
            modifier = Modifier.fillMaxWidth(),
            value=personName.value,
            onValueChange = {
                personName.value = it
            },
            leadingIcon = { Icon(Icons.Filled.Person, null) }
        )

        //Campo: Email
        OutlinedTextField(
            label={ Text(text = "Email Contacto Propietario")},
            modifier = Modifier.fillMaxWidth(),
            value=personEmail.value,
            onValueChange = {
                personEmail.value = it
            },
            leadingIcon = { Icon(Icons.Filled.Mail, null) }
        )

        //Campo: Celular
        OutlinedTextField(
            label={ Text(text = "Celular")},
            modifier = Modifier.fillMaxWidth(),
            value=personPhone.value,
            onValueChange = {
                personPhone.value = it
            },
            leadingIcon = { Icon(Icons.Filled.Phone, null) }
        )
        Row(
        ) {
            OutlinedTextField(
                label={ Text(text = "Mascota")},
                modifier = Modifier
                    .fillMaxWidth(0.5f)
                    .padding(end = 4.dp),
                value=petName.value,
                onValueChange = {
                    petName.value = it
                },
                leadingIcon = { Icon(Icons.Filled.Pets, null) }
            )
            //Campo: Raza Mascota
            OutlinedTextField(
                label={ Text(text = "Raza")},
                modifier = Modifier.padding(start = 4.dp),
                value=petCategory.value,
                onValueChange = {
                    petCategory.value = it
                },
                leadingIcon = { Icon(Icons.Filled.Category, null) }
            )
        }
        //Campo: Sintomas
        OutlinedTextField(
            label={ Text(text = "Describe los sintomas")},
            modifier = Modifier
                .fillMaxWidth()
                .height(128.dp),
            //leadingIcon = { Icon(Icons.Default., null) },
            value=petSymptoms.value,
            onValueChange = {
                petSymptoms.value = it
            },
            maxLines = 16, // Establecer el número de líneas deseadas
            singleLine = false // Permite múltiples líneas

        )

        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = {
                val citaInterface = ApiClient.getCitaService()
                val cita = Cita(
                    id = 0,
                    code = UUID.randomUUID(),
                    petName = petName.value,
                    petCategory = petCategory.value,
                    petSymptoms = petSymptoms.value,
                    personName = personName.value,
                    personEmail = personEmail.value,
                    personPhone = personPhone.value
                )
                val createCita = citaInterface.createCita(cita)

                createCita.enqueue(object: retrofit2.Callback<Cita> {
                    override fun onResponse(call : Call<Cita>, response: Response<Cita>) {
                        if(response.isSuccessful) {
                            val nuevaCita = response.body()
                        }else {
                            // Ocurrió un error en el registro de la cita
                            // Maneja el error de acuerdo a tus necesidades
                        }
                    }

                    override fun onFailure(call : Call<Cita>, t:Throwable){

                    }
                })

            },
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(Color(0xFF0079FF))
        ) {
            Text(
                text = "Agregar Cita".toUpperCase(),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
        TextButton(
            onClick = { },
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth()
                .height(48.dp)

        ) {
            Text(
                text = "Administra tus citas".toUpperCase(),
                color = Color(0xFF1B2430),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@ExperimentalMaterial3Api
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    VeterinariacomposableTheme {
        Cita(navController = rememberNavController())
    }
}