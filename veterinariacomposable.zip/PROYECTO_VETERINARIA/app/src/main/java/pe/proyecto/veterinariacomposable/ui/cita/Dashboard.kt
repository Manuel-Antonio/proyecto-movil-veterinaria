package pe.proyecto.veterinariacomposable.ui.cita

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage

import pe.proyecto.veterinariacomposable.data.model.Cita
import pe.proyecto.veterinariacomposable.data.remote.ApiClient
import pe.proyecto.veterinariacomposable.ui.Route
import pe.proyecto.veterinariacomposable.ui.theme.VeterinariacomposableTheme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.UUID

@ExperimentalMaterial3Api
@Composable
fun Dashboard(navController: NavController) {
    var personName = remember {
        mutableStateOf("")
    }
    var personEmail = remember {
        mutableStateOf("")
    }
    var personPhone = remember {
        mutableStateOf("")
    }
    var petName = remember {
        mutableStateOf("")
    }
    var petCategory = remember {
        mutableStateOf("")
    }
    var petSymptoms = remember {
        mutableStateOf("")
    }



    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally


    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "MascotaFeliz".toUpperCase(),
            textAlign = TextAlign.Center,
            fontWeight = FontWeight(900),
            fontSize = 42.sp,
            lineHeight = 48.sp,
            color = Color(0xFF0079FF),

            )

        Spacer(modifier = Modifier.height(6.dp))

        // Subtitulo
        Text(
            text = "¡Felicidad y cuidado para tu mascota!",
            textAlign = TextAlign.Center,
            fontWeight = FontWeight(900),
            fontSize = 18.sp,
            lineHeight = 18.sp,
            color = Color(0xFF282A3A),
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        // Agregar la imagen debajo del Spacer
        AsyncImage(
            model = "https://res.cloudinary.com/djsl4a5py/image/upload/v1688367758/VetApp/Frame_5gato_volador_n0snb5.png",
            contentDescription = null,
            modifier = Modifier
                .size(width = 256.dp, height = 256.dp)
                .fillMaxWidth(),
            contentScale = ContentScale.FillWidth
        )
        Spacer(modifier = Modifier.height(16.dp))
        // Subtitulo
        Text(
            text = "-- Nuestas operaciones --",
            textAlign = TextAlign.Center,
            fontWeight = FontWeight(900),
            fontSize = 18.sp,
            lineHeight = 18.sp,
            color = Color(0xFF282A3A),
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            CustomOutlinedButton(onClick = { navController.navigate(Route.Login.route) }, text = "Login")
            CustomOutlinedButton(onClick = {  navController.navigate(Route.Register.route)}, text = "Registro")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            CustomOutlinedButton(onClick = {  navController.navigate(Route.ChangePassword.route)}, text = "Clave")
            CustomOutlinedButton(onClick = {  navController.navigate(Route.Pets.route) }, text = "Cita")
        }

    }
}

@Composable
fun CustomOutlinedButton(
    onClick: () -> Unit,
    text: String
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .width(128.dp)
            .height(128.dp)
            .border(2.dp, Color.hsl(209f, 1f, 0.5f), shape = RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(text = text,
            fontSize = 16.sp,
            color = Color(0xFF0079FF),
            fontWeight = FontWeight(900),
        )
    }
}

@ExperimentalMaterial3Api
@Preview(showBackground = true)
@Composable
fun LoginPreview() {
    VeterinariacomposableTheme {
        Dashboard(navController = rememberNavController())
    }
}