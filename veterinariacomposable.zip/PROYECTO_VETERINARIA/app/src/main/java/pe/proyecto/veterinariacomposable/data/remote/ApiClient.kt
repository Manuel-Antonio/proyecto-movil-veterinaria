package pe.proyecto.veterinariacomposable.data.remote
import pe.proyecto.veterinariacomposable.data.remote.service.CitaService
import pe.proyecto.veterinariacomposable.data.remote.service.UserService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
object ApiClient {

    private val API_BASE_URL = "https://materialistic-uncovered-cress.glitch.me/"

    private var retrofit: Retrofit? = null
    private var citaService : CitaService? = null
    private var userService: UserService? = null

    private fun getRetrofit(): Retrofit {
        if (retrofit == null) {
            retrofit = Retrofit.Builder()
                .baseUrl(API_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofit as Retrofit
    }


    fun getUserService(): UserService {
        if (userService == null){
            userService = getRetrofit().create(UserService::class.java)
        }
        return userService as UserService
    }

    fun getCitaService() : CitaService {
        if(citaService == null) {
            citaService = getRetrofit().create(CitaService ::class.java)
        }
        return citaService as CitaService
    }



}