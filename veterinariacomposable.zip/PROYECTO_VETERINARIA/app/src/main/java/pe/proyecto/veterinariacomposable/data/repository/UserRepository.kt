package pe.proyecto.veterinariacomposable.data.repository

import kotlin.text.Regex
import pe.proyecto.veterinariacomposable.data.model.User
import pe.proyecto.veterinariacomposable.data.remote.ApiClient
import pe.proyecto.veterinariacomposable.util.Result
import pe.proyecto.veterinariacomposable.data.remote.service.UserService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.UUID

class UserRepository(
    private val userService: UserService = ApiClient.getUserService()
) {

    private fun validateUser(username: String, callback: (Result<Boolean>) -> Unit) {

        val regex = Regex("[@0-9]")

        if (regex.containsMatchIn(username)) {
            callback(Result.Error("Usuario no Valido"))
            return
        }

        userService.getUserByName(username).enqueue(object : Callback<List<User>> {

            override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {

                if (!response.isSuccessful) {
                    callback(Result.Error("Unsuccessful response"))
                    return
                }

                if (response.body() == null) {
                    callback(Result.Error("No data found"))
                    return
                }

                if (response.body()!!.isNotEmpty()) {
                    callback(Result.Error("Username already registered"))
                    return
                }

                callback(Result.Success(true))

            }

            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                callback(Result.Error("Validate not available"))
            }
        })
    }

    fun createUser(
        username: String,
        email: String,
        phone: String,
        password: String,
        confirmPassword: String,
        callback: (Result<Boolean>) -> Unit
    ) {

        if (password != confirmPassword) {
            callback(Result.Error("Las contraseñas no coinciden"))
            return
        }

        validateUser(username) { result ->

            if (result is Result.Error) {
                callback(Result.Error(result.message.toString()))
                return@validateUser
            }
            val code = UUID.randomUUID()
            userService.createUser(User(0,code, username, email, phone, password))
                .enqueue(object : Callback<User> {
                    override fun onResponse(call: Call<User>, response: Response<User>) {
                        if (!response.isSuccessful) {
                            callback(Result.Error("Respuesta fallida"))
                            return
                        }

                        if (response.body() == null) {
                            callback(Result.Error("Datos no encontrados"))
                            return
                        }
                        callback(Result.Success(true))

                    }

                    override fun onFailure(call: Call<User>, t: Throwable) {
                        callback(Result.Error("Crear usuario no disponible"))
                    }
                })

        }
    }

    fun loginUser(
        username: String,
        password: String,
        callback: (Result<Boolean>) -> Unit
    ) {
        userService.loginValidate(username, password).enqueue(object : Callback<List<User>> {
            override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                if (!response.isSuccessful) {
                    callback(Result.Error("Respuesta fallida"))
                    return
                }
                if (response.body() == null || response.body()!!.size == 0) {
                    callback(Result.Error("El usuario no existe"))
                    return
                }
                callback(Result.Success(true))

            }

            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                callback(Result.Error("Error al consultar"))
            }
        })
    }

    fun changePasswordUser(
        username: String,
        password: String,
        confirmPassword: String,
        callback: (Result<Boolean>) -> Unit
    ) {
        if (password != confirmPassword) {
            callback(Result.Error("Las contraseñas no coinciden"))
            return
        }
        userService.getUserByName(username).enqueue(object : Callback<List<User>> {

            override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {

                if (!response.isSuccessful) {
                    callback(Result.Error("Unsuccessful response"))
                    return
                }

                val userList = response.body()
                if (userList == null || userList.isEmpty()) {
                    callback(Result.Error("Usuario no está registrado"))
                    return
                }

                val firstUser = userList[0]
                val modifiedUser = firstUser.copy(password = password)

                userService.changePassword(firstUser.id, modifiedUser).enqueue(object : Callback<User> {
                    override fun onResponse(call: Call<User>, response: Response<User>) {
                        if (response.isSuccessful) {
                            callback(Result.Success(true))
                        } else {
                            callback(Result.Error("Error al actualizar la contraseña"))
                        }
                    }

                    override fun onFailure(call: Call<User>, t: Throwable) {
                        callback(Result.Error("Fallo en la solicitud de cambio de contraseña"))
                    }
                })

            }

            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                callback(Result.Error("Validate not available"))
            }
        })


    }




}