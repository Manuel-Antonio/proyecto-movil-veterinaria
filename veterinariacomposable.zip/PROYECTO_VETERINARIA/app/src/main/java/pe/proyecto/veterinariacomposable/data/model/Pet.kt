package pe.proyecto.veterinariacomposable.data.model

data class Pet(
    val id: Int,
    val nombre_mascota: String,
    val raza: String,
    val propietario: String,
    val email: String,
    val celular: String,
    val sintomas: String
)


