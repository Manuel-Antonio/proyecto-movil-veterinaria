package pe.proyecto.veterinariacomposable.data.remote.other

 import pe.proyecto.veterinariacomposable.data.model.Pet
 import retrofit2.Call
 import retrofit2.http.Body
 import retrofit2.http.DELETE
 import retrofit2.http.GET
 import retrofit2.http.POST
 import retrofit2.http.PUT
 import retrofit2.http.Path

interface PetInterface {
    @PUT("pets/{id}")
    fun updatePet(@Path("id") id: Int, @Body pet: Pet): Call<Pet>

    @POST("pets")
    fun createPet(@Body pet: Pet): Call<Pet>

    @GET("pets")
    fun getPets(): Call<List<Pet>>

    @DELETE("pets/{id}")
    fun deletePet(@Path("id") id: Int): Call<Void>
}
