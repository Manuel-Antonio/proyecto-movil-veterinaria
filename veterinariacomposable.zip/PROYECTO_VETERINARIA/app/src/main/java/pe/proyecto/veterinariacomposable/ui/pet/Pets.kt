@file:OptIn(ExperimentalMaterial3Api::class)

package pe.proyecto.veterinariacomposable.ui.pet

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import pe.proyecto.veterinariacomposable.data.model.Pet
import pe.proyecto.veterinariacomposable.data.remote.other.ApiClient
import pe.proyecto.veterinariacomposable.data.remote.other.PetInterface
import pe.proyecto.veterinariacomposable.ui.cita.Cita
import pe.proyecto.veterinariacomposable.ui.theme.VeterinariacomposableTheme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Pets(navController: NavController) {
    val context = LocalContext.current

    // State for holding the list of pets
    val petsState = remember { mutableStateListOf<Pet>() }

    // Fetch the initial list of pets
    LaunchedEffect(Unit) {
        val petInterface = ApiClient.client.create(PetInterface::class.java)
        val response = petInterface.getPets()

        response.enqueue(object : Callback<List<Pet>> {
            override fun onResponse(call: Call<List<Pet>>, response: Response<List<Pet>>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        petsState.addAll(it)
                    }
                } else {
                    // Handle the error
                    Toast.makeText(context, "Failed to fetch pets", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<Pet>>, t: Throwable) {
                // Handle the failure
                Toast.makeText(context, "Failed to fetch pets: ${t.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    // Function to create a new pet
    fun createPet(pet: Pet) {
        val petInterface = ApiClient.client.create(PetInterface::class.java)
        val response = petInterface.createPet(pet)

        response.enqueue(object : Callback<Pet> {
            override fun onResponse(call: Call<Pet>, response: Response<Pet>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        petsState.add(it)
                    }
                } else {
                    // Handle the error
                    Toast.makeText(context, "Failed to create pet", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Pet>, t: Throwable) {
                // Handle the failure
                Toast.makeText(context, "Failed to create pet: ${t.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    // Function to update an existing pet
    fun updatePet(id: Int, pet: Pet) {
        val petInterface = ApiClient.client.create(PetInterface::class.java)
        val response = petInterface.updatePet(id, pet)

        response.enqueue(object : Callback<Pet> {
            override fun onResponse(call: Call<Pet>, response: Response<Pet>) {
                if (response.isSuccessful) {
                    response.body()?.let { pet1 ->
                        val index = petsState.indexOfFirst { it.id == id }
                        if (index != -1) {
                            petsState[index] = pet1
                        }
                    }
                } else {
                    // Handle the error
                    Toast.makeText(context, "Failed to update pet", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Pet>, t: Throwable) {
                // Handle the failure
                Toast.makeText(context, "Failed to update pet: ${t.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    // Function to delete a pet
    fun deletePet(id: Int) {
        val petInterface = ApiClient.client.create(PetInterface::class.java)
        val response = petInterface.deletePet(id)

        response.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    petsState.removeAll { it.id == id }
                } else {
                    // Handle the error
                    Toast.makeText(context, "Failed to delete pet", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                // Handle the failure
                Toast.makeText(context, "Failed to delete pet: ${t.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    Column(
        modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Pet List",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        Button(
            onClick = {
                // Create a new pet
                val newPet = Pet(
                    id = 0, // Assign the appropriate ID here
                    nombre_mascota = "", // Assign the appropriate name here
                    raza = "", // Assign the appropriate breed here
                    propietario = "", // Assign the appropriate owner name here
                    email = " ", // Assign the appropriate owner email here
                    celular = "", // Assign the appropriate owner cellphone here
                    sintomas = "" // Assign the appropriate symptoms here
                )
                createPet(newPet)
            }, modifier = Modifier
                .padding(bottom = 16.dp)
                .height(48.dp)
        ) {
            Text(
                text = "Add Pet",
                color = Color(0xFFFFFFFF),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(petsState) { pet ->
                PetListItem(pet = pet, onUpdateClick = { updatedPet ->
                    // Update the pet
                    updatePet(pet.id, updatedPet)
                }, onDeleteClick = {
                    // Delete the pet
                    deletePet(pet.id)
                })
            }
        }
    }
}

@ExperimentalMaterial3Api
@Composable
fun PetListItem(
    pet: Pet, onUpdateClick: (Pet) -> Unit, onDeleteClick: (Int) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(19.dp), shape = RoundedCornerShape(0.dp)
    ) {
        Row(
            modifier = Modifier.padding(21.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 5.dp)
            ) {
                var nombre_mascota by remember { mutableStateOf(pet.nombre_mascota) }
                var raza by remember { mutableStateOf(pet.raza) }
                var propietario by remember { mutableStateOf(pet.propietario) }
                var email by remember { mutableStateOf(pet.email) }
                var celular by remember { mutableStateOf(pet.celular) }
                var sintomas by remember { mutableStateOf(pet.sintomas) }

                Text(
                    text = "Nombre",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterHorizontally)
                )
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp),
                    label = { Text(text = "Escribe aqui nombre de tu mascota...") },
                    value = nombre_mascota,
                    onValueChange = { nombre_mascota = it },
                )

                Text(
                    text = "Raza",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterHorizontally)
                )
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp),
                    label = { Text(text = "Escribe aqui la raza...") },
                    value = raza,
                    onValueChange = { raza = it },
                )

                Text(
                    text = "Propietario",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterHorizontally)
                )
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp),
                    label = { Text(text = "Escribe aqui nombre del propietario...") },
                    value = propietario,
                    onValueChange = { propietario = it },
                )

                Text(
                    text = "Email",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterHorizontally)
                )
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp),
                    label = { Text(text = "Escribe aqui su email ...") },
                    value = email,
                    onValueChange = { email = it },
                )

                Text(
                    text = "Celular",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterHorizontally)
                )
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp),
                    label = { Text(text = "Escribe aqui su número celular ...") },
                    value = celular,
                    onValueChange = { celular = it },
                )

                Text(
                    text = "Síntomas",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterHorizontally)
                )
                TextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp),
                    label = { Text(text = "Escribe aqui los síntomas de su mascota ...") },
                    value = sintomas,
                    onValueChange = { sintomas = it },
                )


                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        onUpdateClick(
                            pet.copy(
                                nombre_mascota = nombre_mascota,
                                raza = raza,
                                propietario = propietario,
                                email = email,
                                celular = celular,
                                sintomas = sintomas
                            )
                        )
                    }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit Pet")
                    }

                    IconButton(onClick = { onDeleteClick(pet.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete Pet")
                    }
                }
            }
        }
    }
}


@ExperimentalMaterial3Api
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    VeterinariacomposableTheme {
        Pets(navController = rememberNavController())
    }
}