package pe.proyecto.veterinariacomposable.data.remote.service

import pe.proyecto.veterinariacomposable.data.model.User
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface UserService {

    @POST("users")
    fun createUser(@Body user: User): Call<User>

    @GET("users")
    fun getUserByName(@Query("username") username: String): Call<List<User>>

    @GET("users")
    fun loginValidate(
        @Query("username") username: String,
        @Query("password") password: String
    ): Call<List<User>>

    @PUT("users/{id}")
    fun changePassword(@Path("id") id: Int, @Body user:User): Call<User>
}